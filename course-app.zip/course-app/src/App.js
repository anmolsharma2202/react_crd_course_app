import React from 'react';
import logo from './logo.svg';
import { Counter } from './features/counter/Counter';
import './App.css';
import HeaderPage from './common/header.component';
import {Route, Routes,Switch} from 'react-router-dom';
import HomePage from './components/home/home-page.component';
import AboutPage from './components/about/about-page';
import PageNotFound from './components/pageNotFound/page-not-found.component';
import Course from './components/courses/courses.component';
import {store} from './store/store'
function App() {
  return (
    <div className="App" style={{backgroundColor:'black'}}>
      <HeaderPage/>
      
      <Routes>
      
                <Route exact path="/" element={<HomePage/>}/>

                <Route path="/courses" element={<Course/>}/>

                <Route path="/about" element={<AboutPage/>}/>

                <Route path="*" element={<PageNotFound/>}/>          
               
           
      
    </Routes>
    </div>
  );
}

export default App;
