import React from 'react';
import {NavLink} from 'react-router-dom';


const HeaderPage = () => {
  const stylvar= {Color:"purple"}
    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
            <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
      <li className="nav-item active">
        <NavLink className="nav-link" to="/" >Home</NavLink>
      </li>
      <li className="nav-item">
      <NavLink className="nav-link text-m" to="/courses"  >Courses</NavLink></li>
      <li className="nav-item">
      <NavLink className="nav-link" to="/about" >About</NavLink>
      </li>
      &nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;
      <li className="nav-item ">
      <h2><NavLink className="nav-link text-success" to="/about" >GEAR-UP COURSES ACADEMY</NavLink></h2>
      </li>
    </ul>
    
    
            </div>
        </nav>

        </div>
        
    )
}

export default HeaderPage;