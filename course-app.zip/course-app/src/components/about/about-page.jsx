import React from 'react'
import { Link } from 'react-router-dom';
const AboutPage = () => {
    return (
        <div>
            <div className="div-one"></div>

<div className="div-two" ></div>


<div className="overlay"></div>

<div className="box">
  <h1>About</h1>
  <br/>
  <p style={{textColor:'blue'}}>Guided by- Mrs Vranda Daga<br/>
            Done by-Anmol Sharma
            </p>



</div>
            
            <br/><br/><br/><br/><br/><br/><br/>
            <br/><br/><br/><br/><br/><br/><br/>
            <br/><br/><br/><br/><br/><br/><br/>
            <br/><br/>
        </div>
    )
}

export default AboutPage;
