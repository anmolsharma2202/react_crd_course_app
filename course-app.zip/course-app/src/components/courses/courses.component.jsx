import React, { useState, useEffect } from "react";
import { courseReducer } from "../../store/courses/courses.reducer";
import "./courses.styles.scss";
import { connect } from "react-redux";
import * as actions from "../../store/courses/courses.action";
import { ACTION_TYPES } from "../../store/courses/courses.types";

const initalForm = {
//  id: "",
  title: "",
  authorId: "",
  category: "",
};

const Course = (props) => {
  const [currentId,setCurrentId]=useState(0)

  useEffect(() => {
    props.fetchAllCourses();
  }, []);

  const [ values, setValues ] = useState(initalForm);

  const handleChange =e=> {
    const {name,value} = e.target
    setValues({ 
      ...values,
      [name]:value
    })
  }

  const handleSubmit = e =>{
    e.preventDefault()
    console.log(values)
    
      props.createCourses(values,()=>{window.alert('New Course Added')})
    // else
    //   props.updateCourses(props.currentId,values,()=>{window.alert(' Course Updated')})
  }

// useEffect(()=>{
//   if(props.currentId!= 0 )
//   setValues({
//     ...props.courseList.find(x=>x.id==props.currentId)
//   })
// },[props.currentId])

const onDelete=id=>{
  
    props.deleteCourses(id,()=>{window.alert(' Course Deleted')})
}







  return (
    <div style={{backgroundColor:"black"}}>
    <div className="course-container" style={{width:'50%'}}>
      <div className="form-container" >
        <h2>Add Courses</h2>
      <form onSubmit={handleSubmit} >     {/* For EDIT-{...({currentId,setCurrentId})} */}
      <div className="input-container">
          <div className="form-group col-sm-4">
            <input
            // label="Course Id"
            value={values.id}
          name="id"
            
            
              className="form-control"
              placeholder="Course ID (autouploaded)"
              readOnly="readonly"
            />
            <br />
            <input
             label="Title"
              value={values.title}
              name="title"
              onChange={handleChange}
              type="text"
              className="form-control"
              placeholder="Enter the Title of the Course"
              required
            />
            <br />
            <input
             label="Author ID"
              value={values.authorId}
              name="authorId"
              onChange={handleChange}
              type="text"
              className="form-control"
             required
              placeholder="Enter Author Id"
            />
            <br />
            <input
            label="Category"
            value={values.category}
             name="category"
             onChange={handleChange}
              type="text"
              className="form-control "
              placeholder="Enter Category"
              required
            />
          </div>
          </div>
          <br />
          <button type="submit"  className="btn btn-primary ">
            Submit
          </button>
        </form>
      </div>
      <br />
      <div className="table-container">
        <h1>Display Added Courses</h1>
        <table className="table table-hover table-dark">
          <thead>
            <tr>
              <th scope="col">#Id</th>
              <th scope="col">Title</th>
              <th scope="col">Author</th>
              <th scope="col">Category</th>
              <th scope="col"> </th>
            </tr>
          </thead>
          <tbody>
            {props.courseList.map((course,id) => {
              return (
                <tr key={id}>
                  <th>{course.id}</th>
                  <td>{course.title}</td>
                  <td>{course.authorId}</td>
                  <td>{course.category}</td>
                  <td>
                    {/* <button className="btn btn-warning" onClick={()=>{setCurrentId(course.id)}}>EDIT</button> */}
                    &nbsp;&nbsp;
                    <button className="btn btn-danger" onClick={()=> onDelete(course.id)}>DELETE</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
    <br/>
    <br/><br/><br/><br/>
    </div>
  );
};

const mapStateToProps = (state) => ({
  courseList: state.courseReducer.list,
});

const mapActionToProps = {
  fetchAllCourses: actions.fetchAll,
  createCourses:actions.create,
  updateCourses:actions.update,
  deleteCourses:actions.Delete
};

export default connect(mapStateToProps, mapActionToProps)(Course);
