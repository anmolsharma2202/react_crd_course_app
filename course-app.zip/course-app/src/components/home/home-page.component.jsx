import React from 'react';
import './home.styles.css'

const HomePage = () => {
    return (
        <div style={{backgroundColor:'crimson'}} >
            <h1 style={{color:'burlywood'}}>Welcome to Courses Academy</h1>
            
            <p>Simple CRUD operation</p>
           
            <div className='wrapper' id='hermes'>
  <div className='blurred-wrapper'>
    <div className='blurred'>LEARN ACCELERATE GROW</div>
  </div>
  <div className='still'>LEARN ACCELERATE GROW</div>
</div>

<div className='wrapper' id='sonic'>
  <div className='blurred-wrapper'>
    <img className='blurred' src='http://2.bp.blogspot.com/-IixO6EttRfY/T25DaTUWJ-I/AAAAAAAAAUo/1lJ7DuKYS6k/s1600/Sonic_runsmall.png' height='100'></img>
  </div>
  <img className='still' src='http://2.bp.blogspot.com/-IixO6EttRfY/T25DaTUWJ-I/AAAAAAAAAUo/1lJ7DuKYS6k/s1600/Sonic_runsmall.png' height='100'></img>
</div>

<div className='wrapper' id='spacex'>
  <div className='blurred-wrapper'>
    <div className='blurred'>REACT PROJECT</div>
  </div>
  <div className='still'>REACT PROJECT</div>
</div>
<br/><br/><br/><br/>
        </div>
    )
}

export default HomePage