import { combineReducers } from "redux";
import { courseReducer } from "./courses/courses.reducer";


export const reducers = combineReducers({
    courseReducer
})