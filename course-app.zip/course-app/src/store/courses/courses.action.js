import api from '../../utils/api.utils'
import { ACTION_TYPES } from './courses.types'




export const fetchAll=()=>dispatch => 
    {
        api.courses().fetchAll()
        .then(
            response=>{
                console.log(response)
                dispatch({
                    type:ACTION_TYPES.FETCH_ALL,
                    payload: response.data
                })
            }
        )
        .catch(error=>console.log(error))
        
    }

export const create = (data,onSuccess)=> dispatch=>
{
    api.courses().create(data)
    .then(response =>{
        dispatch({
            type:ACTION_TYPES.CREATE,
            payload: response.data
        })
        onSuccess()
    })
    .catch(error=>console.log(error))
}

export const update = (id,data,onSuccess)=> dispatch=>
{
    api.courses().update(id,data)
    .then(response =>{
        dispatch({
            type:ACTION_TYPES.UPDATE,
            payload: {id, ...data}
        })
        onSuccess()
    })
    .catch(error=>console.log(error))
}

export const Delete = (id,onSuccess)=> dispatch=>
{
    api.courses().delete(id)
    .then(response =>{
        dispatch({
            type:ACTION_TYPES.DELETE,
            payload:id
        })
        onSuccess()
    })
    .catch(error=>console.log(error))
}